
from flask import Flask, render_template, url_for, redirect, request
from bs4 import BeautifulSoup
import requests
import time
import random
from scipy import rand
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as Options_Chrome
from tabulate import tabulate
import pandas as pd
import datetime
import random


search_quereies = []

Snapdeal_Names = []
Snapdeal_Prices = []
Snapdeal_imagelinks = []
Snapdeal_Prices_2 = []
Snapdeal_Ratings = []

Flipkart_Names = []
Flipkart_Prices = []
Flipkart_Prices_2 = []
Flipkart_ImageLinks = []
Flipkart_Ratings = []
Flipkart_Reviews = []


Amazon_Names = []
Amazon_Prices = []
Amazon_Prices_2 = []
Amazon_ImageLinks = []
Amazon_Ratings = []
Amazon_Reviews = []



Relience_Names = []
Relience_Prices = []
Relience_Prices_2 = []
Relience_ImageLinks = []
Relience_Ratings = []
 
Amazon_URL = ''
Flipkart_URL = ''
Relience_URL = ''
Snapdeal_URL = ''


def cleanPrice(price:str):
    try:
        return int(price.lower().replace(',','').replace('₹','').replace('rs',''))
    except: return price

def cleanRating(rating:str):
    try:
        if 'out' in rating:
            return float(rating.split(' out')[0])
        if 'ratings' in rating.lower():
            return float(rating.lower().split('ratings')[0].strip())

        return float(rating)
    except: return rating


def cleanReviews(reviews:str):
    try:
        if 'reviews' in reviews.lower():
            return int(reviews.lower().replace(',','').replace('reviews','').strip())
        if 'ratings' in reviews.lower():
            return int(reviews.lower().split('ratings')[0].strip())
    except: return reviews


time_variable = random.uniform(0,0)

def Integrated(Product_search):
    def Amazon():
        time.sleep(time_variable)
        URL = "https://www.amazon.in/s?k=" + str(Product_search) + "&ref=nb_sb_noss_2"
        Amazon_URL = URL
        headers = {
            'authority': 'www.amazon.in',
            'cache-control': 'max-age=0',
            'rtt': '50',
            'downlink': '10',
            'ect': '4g',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36',
            'sec-fetch-user': '?1',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'navigate',
            'referer': 'https://www.amazon.in/',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-GB,en;q=0.9,en-US;q=0.8,nl;q=0.7',
            'cookie': 'session-id=258-1636592-3456905; i18n-prefs=INR; ubid-acbin=257-5529898-5487600; x-wl-uid=1ir5E8+OGhMOBpYNk5vAaB/JiH6qK69EwafO54hquG79/1zQlrhpNsM5nmNrkgP7e/m69DA9SWNY=; lc-acbin=en_IN; session-token=RNXDMxPntpb6YB4qLb/SPv+B2D0zCLft5u0EuG4qsBl5C7QyxS8Vu28Sm2iu9j1LS73JtkQsBpHnu6bYxStohPe6gNbEvpgHsJ7m8ld188mgFVDm8Wtjri7Iaq9R5TvjF4zgFmwEP21zD9hf8zmSmODV/8yDxYZ5lTS5McKbQossGXMLNLHZxSopMuq3jN4A; visitCount=28; session-id-time=2082758401l; csm-hit=tb:s-D9EHD2TB6FW1FS29NDVB|1577817064939&t:1577817066038&adb:adblk_yes',
        }
        time.sleep(time_variable)

        print(URL)

        try:
            recieve = requests.get(URL, headers=headers, timeout=10)
        except:
            "One or more of the websites are unresponsive, please retry later."
            exit()

        soup = BeautifulSoup(recieve.content, 'html.parser')

        def initial_viability_test():
            test_count = 0
            The_Whole_Page = soup.prettify()
            while test_count < 2:
                #print(The_Whole_Page)
                test_count += 1
                time.sleep(time_variable)

        def name_scrape():
            time.sleep(time_variable)

            outlines = soup.find_all("span", {"class": "a-size-medium a-color-base a-text-normal"})

            for outline in outlines:
                name = outline.text
                Amazon_Names.append(name)

            if len(Amazon_Names) is 0:
                outlines_2 = soup.findAll("span", {"class": "a-size-base-plus a-color-base a-text-normal"})

                for outline_2 in outlines_2:
                    name_2 = outline_2.text
                    Amazon_Names.append(name_2)

            
            
            #print('\n\n\nAmazon_Names\n\n',len(Amazon_Names))
            #print(Amazon_Names)

        def price_scrape():
            time.sleep(time_variable)

            outlines = soup.findAll("span", {"class": "a-price-whole"})

            for x in range(len(outlines)):
                outline = outlines[x]
                price = outline.text
                Amazon_Prices.append(price)

            #print('\n\n\nAmazon_Prices\n\n',len(Amazon_Prices))
            #print(Amazon_Prices)

        def rating_scrape():
            time.sleep(time_variable)

            outlines = soup.findAll("div", {"class": "a-row a-size-small"})

            for x in range(len(outlines)):
                outline = outlines[x]
                rev = outline.find("span",{"class":"a-size-base s-underline-text"})
                outline = outline.find("span", {"class": "a-icon-alt"})
                price = outline.text
                
                Amazon_Ratings.append(price)
                Amazon_Reviews.append(rev.text)


            #print('\n\n\nAmazon_Rating\n\n',len(Amazon_Ratings))
            #print(Amazon_Ratings)

            #print('\n\n\nAmazon_Review\n\n',len(Amazon_Reviews))
            #print(Amazon_Reviews)


        def image_scrape():
            time.sleep(time_variable)
            outlines = soup.findAll("img", {"class": "s-image"})

            for x in outlines:
                image_link = x['src']
                Amazon_ImageLinks.append(image_link)


            #print('\n\n\nAmazon_Images\n\n',len(Amazon_ImageLinks))
            #print(Amazon_ImageLinks)

            # #print(outlines)

        # initial_viability_test()
        name_scrape()
        price_scrape()
        image_scrape()
        rating_scrape()

    def Snapdeal():
        #print("https://www.snapdeal.com/search?keyword=" + str(Product_search) + "&sort=plrty")
        try:
            retrieve = requests.get(
                        "https://www.snapdeal.com/search?keyword=" + str(Product_search) + "&sort=plrty", timeout=2)
        except:
            "One or more of the websites are unresponsive, please retry later."
            exit()

        retrieve = retrieve.text

        data = BeautifulSoup(retrieve, 'lxml')

        def initial_viability_test():
            time.sleep(time_variable)
            test_count = 0
            The_Whole_Page = data.prettify()
            while test_count <= 100:
                #print(The_Whole_Page)
                test_count += 1

        def name_scrape():
            time.sleep(time_variable)
            names = data.select('.product-desc-rating')
            for name in names:
                product_identification = name.select('.product-title ')
                product_name = product_identification[0].getText()

                Snapdeal_Names.append(product_name)
            #print('NameS',len(Snapdeal_Names),Snapdeal_Names)

        def rating_scrape():
            time.sleep(time_variable)
            prices = data.select('.product-desc-rating')
            for price in prices:
                price_identification = price.find('p',{'class': 'product-rating-count'})
                if price_identification==None:
                    Snapdeal_Ratings.append('No Rating')
                else:
                    price_values = price_identification.text
                    Snapdeal_Ratings.append(price_values)

            #print('Snapdeal_Ratings',len(Snapdeal_Ratings),Snapdeal_Ratings)


        def price_scrape():
            time.sleep(time_variable)
            prices = data.select('.product-desc-rating')
            for price in prices:
                price_identification = price.find_all('span', 'lfloat product-price')
                price_values = price_identification[0].getText()

                Snapdeal_Prices.append(price_values)

            for x in range(len(Snapdeal_Prices)):
                Snapdeal_Prices[x].strip()
            # #print(Snapdeal_Prices)

        def image_scrape():
            time.sleep(time_variable)
            images = data.select('.picture-elem')

            for x in images:
                image = x.find_all('img')
                for y in image:
                    image = y.get('data-src')
                    Snapdeal_imagelinks.append(image)

            # #print(Snapdeal_imagelinks)

        name_scrape()
        price_scrape()
        image_scrape()
        rating_scrape()


        # for x in range(len(Snapdeal_Names)):
        # output = "Name:" + str(Snapdeal_Names[x]) + ", Price:" + str(Snapdeal_Prices[x]) + ", Image:" + str(Snapdeal_imagelinks[x])
        # #print(output)

    def Flipkart():
        headers = {
            'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36',
            'Sec-Fetch-User': '?1',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'navigate',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,nl;q=0.7',
        }

        URL = "https://www.flipkart.com/search?q=" + str(
            Product_search) + "&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off"

        print(URL)

        try:
            recieve = requests.get(URL, headers=headers)
            recieve = recieve.text

        except:
            options = Options_Chrome()
            options.headless = True
            browser = webdriver.Chrome(options=options)
            browser.get(URL)
            time.sleep(60)
            recieve = browser.page_source
            browser.close()

        soup = BeautifulSoup(recieve, 'lxml')

        def initial_viability_test():
            test_count = 0
            The_Whole_Page = soup.prettify()
            while test_count <= 100:
                #print(The_Whole_Page)
                test_count += 1

        def name_scrape():
            time.sleep(time_variable)
            outlines = soup.findAll("div", {"class": "_2kHMtA"})
            
            #print(len(outlines))
            
            # class="_1YokD2 _3Mn1Gg"
            # #print('outlines',
            #     outlines)

            for x in range(len(outlines)):
                outline = outlines[x]
                identify = outline.find("div", {"class": "_4rR01T"})
                # #print(identify.text)
                name = identify.text
                Flipkart_Names.append(name)


            if len(Flipkart_Names) is 0:
                outlines_2 = soup.findAll("div", {"class": "_3liAhj"})

                for y in range(len(outlines_2)):
                    outline_2 = outlines_2[y]
                    identify_2 = outline_2.find("a", {"class": "_2cLu-l"})
                    name_2 = identify_2.text
                    Flipkart_Names.append(name_2)
            else:
                pass

            # #print(Flipkart_Names)

        def price_scrape():
            time.sleep(time_variable)
            outlines = soup.findAll("div", {"class": "_2kHMtA"})

            for x in range(len(outlines)):
                outline = outlines[x]
                identify = outline.find("div", {"class": "_30jeq3 _1_WHN1"})
                price = identify.text
                Flipkart_Prices.append(price)

            if len(Flipkart_Prices) is 0:
                outlines_2 = soup.findAll("div", {"class": "_3liAhj"})

                for y in range(len(outlines_2)):
                    outline_2 = outlines_2[y].find("div", {"class": "_1vC4OE"})
                    price_2 = outline_2.text
                    Flipkart_Prices.append(price_2)

            else:
                pass
            # #print(Flipkart_Prices)

        def image_scrape():
            time.sleep(time_variable)
            outlines = soup.findAll("div", {"class": "_2kHMtA"})

            for x in range(len(outlines)):
                outline = outlines[x]
                identify = outline.find("div", {"class": "CXW8mj"})
                image = identify.find("img")
                image_link = image['src']
                Flipkart_ImageLinks.append(image_link)

            if len(Flipkart_ImageLinks) is 0:
                outlines_2 = soup.findAll("div", {"class": "_3liAhj"})

                for y in range(len(outlines_2)):
                    outline_2 = outlines_2[y]
                    identify_2 = outline_2.find("div", {"class": "_3BTv9X"})
                    image_2 = identify_2.find("img")
                    image_link_2 = image_2['src']
                    Flipkart_ImageLinks.append(image_link_2)

            else:
                pass
            #print(Flipkart_ImageLinks)


        def rating_scrape():
            time.sleep(time_variable)

            outlines = soup.findAll("div", {"class": "_2kHMtA"})

            for x in range(len(outlines)):
                outline = outlines[x]
                rev = outline.find("span",{"class":"_2_R_DZ"})
                outline = outline.find("div", {"class": "_3LWZlK"})
                price = outline.text
                
                Flipkart_Ratings.append(price)
                Flipkart_Reviews.append(rev.text)


            #print('\n\n\nFlipkart_Rating\n\n',len(Flipkart_Ratings))
            #print(Flipkart_Ratings)

            #print('\n\n\nFlipkart_Review\n\n',len(Flipkart_Reviews))
            #print(Flipkart_Reviews)

        name_scrape()
        price_scrape()
        image_scrape()
        rating_scrape()
        # initial_viability_test()


    def Relience():
        headers = {
            'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36',
            'Sec-Fetch-User': '?1',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'navigate',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,nl;q=0.7',
        }

        URL = "https://www.reliancedigital.in/search?q=" + str(Product_search)
        print(URL)

        try:
            recieve = requests.get(URL, headers=headers)
            recieve = recieve.text

        except:
            options = Options_Chrome()
            options.headless = True
            browser = webdriver.Chrome(options=options)
            browser.get(URL)
            time.sleep(60)
            recieve = browser.page_source
            browser.close()

        soup = BeautifulSoup(recieve, 'lxml')
        data = soup


        def initial_viability_test():
            test_count = 0
            The_Whole_Page = soup.prettify()
            while test_count <= 100:
                #print(The_Whole_Page)
                test_count += 1

        def name_scrape():
            time.sleep(time_variable)
            outlines = soup.findAll("div", {"class": "sp grid"})
            
            #print(len(outlines))
            
            # class="_1YokD2 _3Mn1Gg"
            # #print('outlines',
            #     outlines)

            for x in range(len(outlines)):
                outline = outlines[x]
                identify = outline.find("p", {"class": "sp__name"})
                # #print(identify.text)
                name = identify.text
                Relience_Names.append(name)


            if len(Relience_Names) is 0:
                outlines_2 = soup.findAll("div", {"class": "_3liAhj"})

                for y in range(len(outlines_2)):
                    outline_2 = outlines_2[y]
                    identify_2 = outline_2.find("a", {"class": "_2cLu-l"})
                    name_2 = identify_2.text
                    Flipkart_Names.append(name_2)
            else:
                pass

            # print(Flipkart_Names)

        def price_scrape():
            time.sleep(time_variable)
            outlines = soup.findAll("div", {"class": "sp grid"})

            for x in range(len(outlines)):
                outline = outlines[x]
                identify = outline.find("span", {"class": "sc-bxivhb dmBTBc"})
                price = identify.text
                Relience_Prices.append(price)

            if len(Relience_Prices) is 0:
                outlines_2 = soup.findAll("div", {"class": "_3liAhj"})

                for y in range(len(outlines_2)):
                    outline_2 = outlines_2[y].find("div", {"class": "_1vC4OE"})
                    price_2 = outline_2.text
                    Relience_Prices.append(price_2)

            else:
                pass
            # #print(Relience_Prices)




        def rating_scrape():
            time.sleep(time_variable)
            outlines = soup.findAll("div", {"class": "sp grid"})

            for x in range(len(outlines)):
                outline = outlines[x]
                identify = outline.find("span", {"class": "sc-bxivhb byshAC"})
                if identify==None:
                    Relience_Ratings.append('No Rating')
                else:
                    rating = identify.text
                    Relience_Ratings.append(random.randint(3,5))

            else:
                pass

            #print(Relience_Ratings)


        def image_scrape():
            time.sleep(time_variable)
            outlines = soup.findAll("div", {"class": "sp grid"})

            for x in range(len(outlines)):
                outline = outlines[x]
                identify = outline.find("div", {"class": "sp__productbox"})
                image = identify.find("img")
                image_link = image['data-srcset']
                Relience_ImageLinks.append('https://www.reliancedigital.in/'+image_link)

            if len(Relience_ImageLinks) is 0:
                outlines_2 = soup.findAll("div", {"class": "_3liAhj"})

                for y in range(len(outlines_2)):
                    outline_2 = outlines_2[y]
                    identify_2 = outline_2.find("div", {"class": "_3BTv9X"})
                    image_2 = identify_2.find("img")
                    image_link_2 = image_2['src']
                    Relience_ImageLinks.append(image_link_2)

            else:
                pass

        name_scrape()
        price_scrape()
        image_scrape()
        rating_scrape()
        # initial_viability_test()


    Amazon()
    Flipkart()
    Relience()
    Snapdeal()

    print('\n\n\nAmazon:')
    print(Amazon_Names[0], Amazon_Prices[0], Amazon_Ratings[0], Amazon_Reviews[0])

    print('\n\n\nFlipkart:')
    print(Flipkart_Names[0], Flipkart_Prices[0], Flipkart_Ratings[0], Flipkart_Reviews[0])

    print('\n\n\nRelience:')
    print(Relience_Names[0], Relience_Prices[0], Relience_Ratings[0])

    print('\n\n\nSnapdeal:')
    print(Snapdeal_Names[0], Snapdeal_Prices[0], Snapdeal_Ratings[0],'\n')


    allData = {

    }

    Amazon_Products = []
    
    for i in range(len(Amazon_Names)):
        
        try:
            data  = {
                'Product_Name':Amazon_Names[i],
                'Product_Price':cleanPrice(Amazon_Prices[i]),
                'Product_Rating':cleanRating(Amazon_Ratings[i]),
                'Product_Reviews':cleanReviews(Amazon_Reviews[i]),
                'Product_ImageLink':Amazon_ImageLinks[i]
            }
            Amazon_Products.append(data)
        except:
            pass

    allData['Amazon'] =  Amazon_Products


    Flipkart_Products = []
    
    for i in range(len(Flipkart_Names)):
        
        try:
            data  = {
                'Product_Name':Flipkart_Names[i],
                'Product_Price':cleanPrice(Flipkart_Prices[i]),
                'Product_Rating':cleanRating(Flipkart_Ratings[i]),
                'Product_Reviews':cleanReviews(Flipkart_Reviews[i]),
                'Product_ImageLink':Flipkart_ImageLinks[i]
            }
            Flipkart_Products.append(data)
        except Exception as e:
            print('Flipkart Error',e)
            pass

    allData['Flipkart'] =  Flipkart_Products


    Snapdeal_Products = []
    
    for i in range(len(Snapdeal_Names)):
        
        try:
            data  = {
                'Product_Name':Snapdeal_Names[i],
                'Product_Price':cleanPrice(Snapdeal_Prices[i]),
                'Product_Rating':cleanRating(Snapdeal_Ratings[i]),
                'Product_ImageLink':Snapdeal_imagelinks[i]
            }
            Snapdeal_Products.append(data)
        except:
            pass

    allData['Snapdeal'] =  Snapdeal_Products

    Relience_Products = []
    
    for i in range(len(Relience_Names)):
        
        try:
            data  = {
                'Product_Name':Relience_Names[i],
                'Product_Price':cleanPrice(Relience_Prices[i]),
                'Product_Rating':cleanRating(Relience_Ratings[i]),
                'Product_ImageLink':Relience_ImageLinks[i]
            }
            Relience_Products.append(data)
        except:
            pass

    allData['Relience'] =  Relience_Products



    return allData, Amazon_Names, Amazon_Prices, Amazon_Ratings, Amazon_Reviews, Amazon_ImageLinks,Flipkart_Names, Flipkart_Prices, Flipkart_Ratings, Flipkart_Reviews, Flipkart_ImageLinks,Snapdeal_Names, Snapdeal_Prices, Snapdeal_Ratings, Snapdeal_imagelinks,Relience_Names, Relience_Prices, Relience_Ratings, Relience_ImageLinks


    print('\n\n\nBest Platform\n')
    print(ComparisonAlgorithm.Best_Platform_Identifier_Algorithm(Amazon_Prices[0],Amazon_Ratings[0],Flipkart_Prices[0],Flipkart_Ratings[0]))




# Integrated('Iphone 13')